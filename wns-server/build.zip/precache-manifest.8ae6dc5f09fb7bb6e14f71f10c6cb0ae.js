self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aa71ff72fa53344f29cd8362c3c6598b",
    "url": "./index.html"
  },
  {
    "revision": "bb193ad23e669ec4a3c3",
    "url": "./static/css/2.7997b379.chunk.css"
  },
  {
    "revision": "5bc19cb31a166020c56e",
    "url": "./static/css/main.dd0e70ee.chunk.css"
  },
  {
    "revision": "bb193ad23e669ec4a3c3",
    "url": "./static/js/2.fe7d51f3.chunk.js"
  },
  {
    "revision": "5bc19cb31a166020c56e",
    "url": "./static/js/main.1c0aa17b.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "70bb0104c114cd113add81b363a659d1",
    "url": "./static/media/bg_tree.70bb0104.png"
  },
  {
    "revision": "15841f8c288287bf8a11566f899b9937",
    "url": "./static/media/logo-title.15841f8c.png"
  },
  {
    "revision": "6db277b732d580e4991c90ccfdeef3dc",
    "url": "./static/media/loukong.6db277b7.ttf"
  }
]);